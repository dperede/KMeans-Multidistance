__name__="KMeans_Multidistance"
__version__ = "0.0.1"